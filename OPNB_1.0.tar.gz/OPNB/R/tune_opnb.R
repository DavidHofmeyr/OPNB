### Function OPNB fits a model for given arguments:
# X = numeric matrix with observations row-wise
# y = vector of class labels for the observations
# ndim = number of projection directions. Default is min(ncol(X), 20)
# lam = strength of penalty. Must be strictly greater than zero. Default is 1e-3.
# V0 = Initial projection matrix. By default uses the first ndim principal components of the data (after pre-processing).
#       for customised initialisation you can provide a function V0(X, y, ndim)
# scale = should the individual columns in X be scaled to have unit variance? default is TRUE
# nbin = number of bins used in kernel computations. If exact computation is desired, set equal to NULL. Default is 1000

### The output has class 'OPNB' which has methods 'predict' and 'plot'

OPNB <- function(X, y, ndim = min(ncol(X), 20), lam = 1e-3, V0 = NULL, scale = TRUE, nbin = 1000, C = NULL){
  n <- nrow(X)
  d <- ncol(X)
  ynames <- levels(yy <- as.factor(y))
  y <- as.numeric(yy)
  Xo <- X
  mn <- colMeans(X)
  X <- X-matrix(mn, n, d, byrow = TRUE)
  if(scale) scales <- apply(X, 2, function(x) ifelse(sd(x)<1e-20, 0, 1/sd(x)))
  else scales <- rep(1, d)
  X <- X*matrix(scales, n, d, byrow = TRUE)
  PI <- sapply(1:max(y), function(k) sum(y==k))/n
  if(is.null(V0)) V <- eigen(cov(X))$vectors[,1:ndim]
  else if(is.function(V0)){
    V <- V0(X, y, ndim)
    if(!is.matrix(V) | ncol(V)!=ndim | nrow(V)!=d) stop('The output of V0 should be a matrix of dimension ncol(X) x ndim')
  }
  else stop('for custom initialisation V0 must be a function of X, y and ndim')
  
  h <- rep(1, max(y))
  
  if(is.null(C)){
    pen <- function(V) sum(V^2)
    dpen <- function(V) 2*V
  }
  else if(is.function(C)){
    Cmat <- C(X, y)
    pen <- function(V) sum(apply(matrix(V, nrow = d), 2, function(v) t(v)%*%Cmat%*%v))
    dpen <- function(V) 2*Cmat%*%matrix(V, nrow = d)
  }
  else stop('C must be a function of X and y returning a square matrix with ncol(X) rows and columns')
  
  if(is.null(nbin)){
    ffun <- function(V, X, y, PI, h, lam) f_NB_exact(matrix(V, nrow = d), X, y, PI, h) - lam*pen(V)
    dffun <- function(V, X, y, PI, h, lam) c(df_NB_exact(matrix(V, nrow = d), X, y, PI, h)) - lam*c(dpen(V))
  }
  else{
    ffun <- function(V, X, y, PI, h, lam) f_NB_cpp(matrix(V, nrow = d), X, y, PI, h, nbin = nbin) - lam*pen(V)
    dffun <- function(V, X, y, PI, h, lam) c(df_NB_cpp(matrix(V, nrow = d), X, y, PI, h, nbin = nbin)) - lam*c(dpen(V))
  }
  Vout <- try(optim(V, ffun, dffun, X, y-1, PI, h, lam, method = 'L-BFGS-B', control = list(fnscale = -1))$par)
  if(inherits(Vout, 'try-error')){
    warning('Numerical errors occurred with settings provided, returning initial solution. Try using a larger value for lam')
    Vout <- V
  }
  
  fval <- ffun(Vout, X, y-1, PI, h, lam)
  
  vals <- sapply(1:ndim, function(p) ffun(matrix(Vout[,p], ncol = 1), X, y-1, PI, h, lam = 0))
  incl <- which.max(vals)
  for(j in 2:ndim){
    vals <- sapply((1:ndim)[-incl], function(p) ffun(matrix(Vout[,c(incl, p)], nrow = d), X, y-1, PI, h, lam = 0))
    incl <- c(incl, (1:ndim)[-incl][which.max(vals)])
  }
  V <- Vout[,incl]
  norms <- sqrt(colSums(V^2))
  hmat <- h%*%t(1/norms)
  V <- V/matrix(norms, d, ndim, byrow = TRUE)

  sol <- list(V=V*scales, X = Xo, y=y, PI=PI, h=hmat, nc = max(y), mu = mn, scales = scales, ynames = ynames, lam = lam, fval = fval)
  class(sol) <- "OPNB"
  sol
}



### predict method for OPNB operates like most predictive models, and will provide
### estimates for posterior class distributions for the observations in the matrix Xte.
### If you wish not to use all projection dimensions in the fitted model, you can
### specify ndim to a value fewer than the number of columns of sol$V

predict.OPNB <- function(sol, Xte, ndim = NULL){
  if(!is.null(ndim)) sol$V <- sol$V[,1:ndim]
  nte <- nrow(Xte)
  d <- ncol(Xte)
  dd <- ncol(sol$V)
  nc <- sol$nc
  den <- matrix(1, nc, nte)
  p <- sweep(sol$X, 2, sol$mu, '-')%*%sol$V
  pte <- sweep(Xte, 2, sol$mu, '-')%*%sol$V
  ns <- sapply(1:max(sol$y), function(i) sum(sol$y==i))
  for(k in 1:nc){
    for(dm in 1:dd){
      den[k,] <- den[k,]*fk_sum(p[sol$y==k,dm], rep(1/ns[k]/sol$h[k,dm], ns[k]), sol$h[k,dm], x_eval = pte[,dm])
    }
    den[k,] <- den[k,]*sol$PI[k]
  }
  den[which(is.na(den))] <- .Machine$double.eps
  den[which(den<=0)] <- .Machine$double.eps
  den <- t(den)
  list(posterior = den/rowSums(den), class = sol$ynames[apply(den, 1, which.max)])
}



### plot method for OPNB shows decision boundaries obtained from the
### restricted model given by the projections onto only two projection
### dimensions. The projection dimensions have been ordered greedily
### in a forward manner, and so dims 1 and 2 may not display the
### best discrimination by any combination of 2 variables, but should
### show reasonable discrimination. As dims are increased it is likely,
### though not impossible, that visible discriminability in the plot
### will decrease


plot.OPNB <- function(sol, Xte = NULL, dims = c(1, 2), add_cols = FALSE, plot_train = TRUE){
  sol0 <- sol
  Pnb <- sweep(sol$X, 2, sol$mu, '-')%*%sol$V[,dims]
  grid <- as.matrix(expand.grid(seq(min(Pnb[,1])-sd(Pnb[,1])/2, max(Pnb[,1])+sd(Pnb[,1])/2, length = 50), seq(min(Pnb[,2])-sd(Pnb[,2])/2, max(Pnb[,2])+sd(Pnb[,2])/2, length = 50)))
  
  sol0$X <- Pnb
  sol0$V <- diag(2)
  sol0$mu <- numeric(2)
  
  pp <- predict(sol0, grid)
  par(mar = c(2, 2, 3, 1))
  plot(Pnb, col = 0, cex.main = 1.2, main = 'OPNB projection.', xaxt = 'n', yaxt = 'n', xlab = '', ylab = '')
  mtext(bquote(XV[.(dims[1])]), side = 1, line = 0.8)
  mtext(bquote(XV[.(dims[2])]), side = 2, line = 0.8)
  if(add_cols) for(j in 1:max(sol$y)){
    cl <- col2rgb(j+1)/255
    points(grid[pp$class==j,], col = rgb(cl[1], cl[2], cl[3], .05), pch = 15, cex = 1.7)
  }
  
  if(is.null(Xte)) points(Pnb, col = sol$y+1, pch = sol$y%%25, cex = 2)
  else{
    mtext("test obs. shown as black points", side = 3, line = 0.5, cex = 0.8)
    points(Pnb, col = sol$y+1, pch = sol$y%%25, cex = 2)
    points(sweep(Xte, 2, sol$mu, '-')%*%sol$V[,dims], pch = 16, cex = .5, col = rgb(0, 0, 0, .25))
  }
  
  for(j in 1:max(sol$y)) contour(seq(min(Pnb[,1])-sd(Pnb[,1])/2, max(Pnb[,1])+sd(Pnb[,1])/2, length = 50), seq(min(Pnb[,2])-sd(Pnb[,2])/2, max(Pnb[,2])+sd(Pnb[,2])/2, length = 50), matrix(pp$posterior[,j]-apply(matrix(pp$posterior[,-j], nrow = nrow(pp$posterior)), 1, max), 50, 50), levels = c(0), add = TRUE, drawlabels = FALSE, lwd = 2)
  
}

### Performs cross-validation over lambda (penalty strength, called "lam" within the OPNB function) only,
### starting from lam0 (default 1e-4) and increasing in multiples of argument factor (default = 2).
### Argument nlam (default 10) tells how many values to consider, i.e. max lamba = lam0*factor^(nlam-1).
### Validation folds must be provided, as a list with entries containing the indices for that fold.
### For parallelisation (over lambda values) set cores to a value > 1


OPNB_CV_lam <- function(X, y, folds, nlam = 10, lam0 = 1e-4, factor = 2, nbin = 1000, ndim = min(ncol(X), 20), scale = TRUE, cores = 1, V0 = NULL, C = NULL){
  n <- nrow(X)
  d <- ncol(X)
  
  if(cores > 1){
    cluster <- makeCluster(cores)
    clusterExport(cluster, c(ls(), 'OPNB', 'predict.OPNB'), envir = environment())
    
    mods <- parLapply(cl = cluster, 1:nlam,
                      function(x){
                        lam <- lam0*factor^(x-1)
                        yhats <- numeric(n)
                        for(fl in 1:length(folds)){
                          mdd <- OPNB(X[unlist(folds[-fl]),], y[unlist(folds[-fl])], ndim = ndim, nbin = nbin, scale = scale, lam = lam, V0 = V0, C = C)
                          yh <- (predict(mdd, X[folds[[fl]],])$class)
                          if(inherits(yh, 'try-error')) yh <- numeric(length(folds[[fl]]))
                          yhats[folds[[fl]]] <- yh
                        }
                        prfs <- mean(yhats[unlist(folds)] == y[unlist(folds)])
                        return(list(lam = lam, acc = prfs))
                      })
    stopCluster(cluster)
  }
  else mods <- lapply(1:nlam,
                         function(x){
                           lam <- lam0*factor^(x-1)
                           yhats <- numeric(n)
                           for(fl in 1:length(folds)){
                             mdd <- OPNB(X[unlist(folds[-fl]),], y[unlist(folds[-fl])], ndim = ndim, nbin = nbin, scale = scale, lam = lam, V0 = V0, C = C)
                             yh <- (predict(mdd, X[folds[[fl]],])$class)
                             if(inherits(yh, 'try-error')) yh <- numeric(length(folds[[fl]]))
                             yhats[folds[[fl]]] <- yh
                           }
                           prfs <- mean(yhats[unlist(folds)] == y[unlist(folds)])
                           return(list(lam = lam, acc = prfs))
                         })
  cv_stats <- cbind(lam = unlist(lapply(mods, function(l) l$lam)), accuracy = unlist(lapply(mods, function(l) l$acc)))
  selection <- which.max(cv_stats[,'accuracy'])
  list(model = OPNB(X[unlist(folds),], y[unlist(folds)], ndim = ndim, nbin = nbin, scale = scale, lam = mods[[selection]]$lam, V0 = V0, C = C), cv_stats = cv_stats)
}

