#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;

// [[Rcpp::export]]

double f_NB_cpp(arma::mat V, arma::mat X, IntegerVector y, NumericVector mypi, NumericVector h, int nbin){
  int n = arma::size(X)[0];
  int p = arma::size(X)[1];
  int pp = arma::size(V)[1];
  int nc = mypi.size();
  arma::vec nms(pp);
  for(int i=0; i<pp; i++) nms[i] = norm(V.col(i), 2);
  
  NumericVector mins(pp);
  NumericVector maxs(pp);
  for(int j=0; j<pp; j++){
    mins[j] = pow(10, 10);
    maxs[j] = -pow(10, 10);
  }
  
  arma::mat P = X*V;
  for(int j=0; j<pp; j++){
    for(int i=0; i<n; i++){
      if(P(i,j) < mins[j]) mins[j] = P(i,j);
      if(P(i,j) > maxs[j]) maxs[j] = P(i,j);
    }
  }
  
  for(int j=0; j<pp; j++){
    mins[j] -= 1e-7*.1;
    maxs[j] += 1e-7*.1;
  }
  
  arma::cube bin_y(nc,nbin,pp);
  IntegerMatrix alloc(n,pp);
  NumericVector skips(pp);
  
  for(int j=0; j<pp; j++) skips[j] = (nbin - 1.0) / (maxs[j] - mins[j]);
  
  
  int fl = 0;
  double xe;
  
  for(int j=0; j<pp; j++){
    for(int i = 0; i<nbin; i++) for(int k=0; k<nc; k++) bin_y(k,i,j) = 0.0;
    for(int i=0; i<n; i++){
      
      xe = (P(i,j) - mins[j]) * skips[j];
      fl = floor(xe);
      
      alloc(i,j) = fl;
      
      //bin_y(y[i],fl+1,j) += (xe - fl);
      //bin_y(y[i],fl,j) += (fl + 1 - xe);
      
      if(fl < (nbin - 1) && fl >= 0){
        bin_y(y[i],fl+1,j) += (xe - fl);
        bin_y(y[i],fl,j) += (fl + 1.0 - xe);
      }
      else if(fl >= (nbin - 1)) bin_y(y[i],nbin-1,j) += 1.0;
      else bin_y(y[i],0,j) += 1.0;
      
    }
  }
  
  //return(bin_y);
  
  
  
  double emult;
  
  //double L[nc][2][nbin][pp] = {0};
  //double R[nc][2][nbin][pp] {0};
  arma::cube L0(nc, nbin, pp);
  arma::cube L1(nc, nbin, pp);
  arma::cube R0(nc, nbin, pp);
  arma::cube R1(nc, nbin, pp);
  for(int j=0; j<pp; j++){
    for(int k=0; k<nc; k++){
      emult = exp(-1.0/skips[j]/h[k]);
      L0(k,0,j) = bin_y(k,0,j);
      L1(k,0,j) = -mins[j]*bin_y(k,0,j);
      R0(k,nbin-1,j) = 0.0;
      R1(k,nbin-1,j) = 0.0;
      for(int i=1; i<nbin; i++){
        L0(k,i,j) = bin_y(k,i,j) + emult*L0(k,i-1,j);
        L1(k,i,j) = -(mins[j]+(i+0.0)/skips[j])*bin_y(k,i,j) + emult*L1(k,i-1,j);
        R0(k,nbin-i-1,j) = emult*(bin_y(k,nbin-i,j)+R0(k,nbin-i,j));
        R1(k,nbin-i-1,j) = emult*((mins[j]+(nbin-i+0.0)/skips[j])*bin_y(k,nbin-i,j)+R1(k,nbin-i,j));
      }
    }
  }
  
  
  
  
  
  arma::cube densities(nc,nbin,pp);
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<nbin; i++){
        densities(k,i,j) = 0.0;
      }
    }
  }
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<nbin; i++){
        //densities(k,i,j) += L0(k,i,j) + R0(k,i,j) + (mins[j] + (i+0.0)/skips[j])*(L1(k,i,j)-R1(k,i,j));
        //densities(k,i,j) += .25/(n*mypi[k])/h*(L0(k,i,j)*(bin_y(k,i,j)+(mins[j] + (i+0.0)/skips[j])/h)+L1(k,i,j)/h + R0(k,i,j)*(bin_y(k,i,j)-(mins[j] + (i+0.0)/skips[j])/h) + R1(k,i,j)/h);
        densities(k,i,j) += .25/(n*mypi[k])/h[k]*(L0(k,i,j)*(1.0+(mins[j] + (i+0.0)/skips[j])/h[k])+L1(k,i,j)/h[k] + R0(k,i,j)*(1.0-(mins[j] + (i+0.0)/skips[j])/h[k]) + R1(k,i,j)/h[k]);
      }
    }
  }
  
  
  
  double output = 0;
  
  double dentot;
  double denprod;
  //arma::mat dens(n,2);
  //double denc;
  
  //double eps = pow(.1, 100);
  
  for(int i=0; i<n; i++){
    dentot = 0.0;
    for(int k=0; k<nc; k++){
      denprod = 1.0;//*mypi[k];
      for(int j=0; j<pp; j++){
        denprod *= densities(k,alloc(i,j),j);
      }
      dentot += mypi[k]*denprod;
      //if(y[i]==k) dens(i,0) = mypi[k]*denprod;
      if(y[i]==k) output+= log(mypi[k]*denprod);
    }
    //dens(i,1) = dentot;
    output -= log(dentot);
    //output += (denc < 1e-100 ? log(denc) : -100) - (dentot < 1e-100 ? log(dentot) : -50);
  }
  output /= n+0.0;
  return(output);
  //return(dens);
}



// [[Rcpp::export]]

arma::mat df_NB_cpp(arma::mat V, arma::mat X, IntegerVector y, NumericVector mypi, NumericVector h, int nbin){
  int n = arma::size(X)[0];
  int p = arma::size(X)[1];
  int pp = arma::size(V)[1];
  int nc = mypi.size();
  arma::vec nms(pp);
  for(int i=0; i<pp; i++) nms[i] = norm(V.col(i), 2);
  
  NumericVector mins(pp);
  NumericVector maxs(pp);
  for(int j=0; j<pp; j++){
    mins[j] = pow(10, 10);
    maxs[j] = -pow(10, 10);
  }
  
  arma::mat P = X*V;
  for(int j=0; j<pp; j++){
    for(int i=0; i<n; i++){
      if(P(i,j) < mins[j]) mins[j] = P(i,j);
      if(P(i,j) > maxs[j]) maxs[j] = P(i,j);
    }
  }
  
  for(int j=0; j<pp; j++){
    mins[j] -= 1e-7*.1;
    maxs[j] += 1e-7*.1;
  }
  
  arma::cube bin_y(nc,nbin,pp);
  IntegerMatrix alloc(n,pp);
  NumericVector skips(pp);
  
  for(int j=0; j<pp; j++) skips[j] = (nbin - 1.0) / (maxs[j] - mins[j]);
  
  
  int fl = 0;
  double xe;
  
  for(int j=0; j<pp; j++){
    for(int i = 0; i<nbin; i++) for(int k=0; k<nc; k++) bin_y(k,i,j) = 0.0;
    for(int i=0; i<n; i++){
      
      xe = (P(i,j) - mins[j]) * skips[j];
      fl = floor(xe);
      
      alloc(i,j) = fl;
      
      //bin_y(y[i],fl+1,j) += (xe - fl);
      //bin_y(y[i],fl,j) += (fl + 1 - xe);
      
      if(fl < (nbin - 1) && fl >= 0){
        //bin_y(y[i],fl+1,j) += (xe - fl);
        //bin_y(y[i],fl,j) += (fl + 1.0 - xe);
        bin_y(y[i],fl,j) += 1.0;
      }
      else if(fl >= (nbin - 1)) bin_y(y[i],nbin-1,j) += 1.0;
      else bin_y(y[i],0,j) += 1.0;
      
    }
  }
  
  //return(bin_y);
  
  
  
  double emult;
  
  //double L[nc][2][nbin][pp] = {0};
  //double R[nc][2][nbin][pp] {0};
  arma::cube L0(nc, nbin, pp);
  arma::cube L1(nc, nbin, pp);
  arma::cube R0(nc, nbin, pp);
  arma::cube R1(nc, nbin, pp);
  for(int j=0; j<pp; j++){
    for(int k=0; k<nc; k++){
      emult = exp(-1.0/skips[j]/h[k]);
      L0(k,0,j) = bin_y(k,0,j);
      L1(k,0,j) = -mins[j]*bin_y(k,0,j);
      R0(k,nbin-1,j) = 0.0;
      R1(k,nbin-1,j) = 0.0;
      for(int i=1; i<nbin; i++){
        L0(k,i,j) = bin_y(k,i,j) + emult*L0(k,i-1,j);
        L1(k,i,j) = -(mins[j]+(i+0.0)/skips[j])*bin_y(k,i,j) + emult*L1(k,i-1,j);
        R0(k,nbin-i-1,j) = emult*(bin_y(k,nbin-i,j)+R0(k,nbin-i,j));
        R1(k,nbin-i-1,j) = emult*((mins[j]+(nbin-i+0.0)/skips[j])*bin_y(k,nbin-i,j)+R1(k,nbin-i,j));
      }
    }
  }
  
  
  
  
  
  arma::cube densities(nc,nbin,pp);
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<nbin; i++){
        densities(k,i,j) = 0.0;
      }
    }
  }
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<nbin; i++){
        //densities(k,i,j) += L0(k,i,j) + R0(k,i,j) + (mins[j] + (i+0.0)/skips[j])*(L1(k,i,j)-R1(k,i,j));
        //densities(k,i,j) += .25/(n*mypi[k])/h*(L0(k,i,j)*(bin_y(k,i,j)+(mins[j] + (i+0.0)/skips[j])/h)+L1(k,i,j)/h + R0(k,i,j)*(bin_y(k,i,j)-(mins[j] + (i+0.0)/skips[j])/h) + R1(k,i,j)/h);
        densities(k,i,j) += .25/(n*mypi[k])/h[k]*(L0(k,i,j)*(1.0+(mins[j] + (i+0.0)/skips[j])/h[k])+L1(k,i,j)/h[k] + R0(k,i,j)*(1.0-(mins[j] + (i+0.0)/skips[j])/h[k]) + R1(k,i,j)/h[k]);
      }
    }
  }
  
  
  
  double output = 0;
  
  double dentot;
  double denprod;
  arma::mat dens(n,nc+1);
  double denc;
  
  //double eps = pow(.1, 100);
  
  for(int i=0; i<n; i++){
    dentot = 0.0;
    for(int k=0; k<nc; k++){
      denprod = 1.0;
      for(int j=0; j<pp; j++){
        denprod *= densities(k,alloc(i,j),j);
      }
      dentot += mypi[k]*denprod;
      dens(i,k) = denprod;
    }
    dens(i,nc) = dentot;
    //output += (denc < 1e-100 ? log(denc) : -100) - (dentot < 1e-100 ? log(dentot) : -50);
  }
  
  arma::mat dp(n,pp);
  
  for(int s=0; s<n; s++){
    for(int t=0; t<pp; t++){
      dp(s,t) = -(.25/(n*mypi[y[s]])/h[y[s]]/h[y[s]]/h[y[s]]/densities(y[s],alloc(s,t),t)*((L0(y[s],alloc(s,t),t)+R0(y[s],alloc(s,t),t))*(mins[t]+1.0*alloc(s,t)/skips[t])+L1(y[s],alloc(s,t),t)-R1(y[s],alloc(s,t),t)));
      //dp(s,t) = 0;
      for(int k=0; k<nc; k++){
        dp(s,t) += .25/(n+0.0)/h[k]/h[k]/h[k]/dens(s,nc)*dens(s,k)/densities(k,alloc(s,t),t)*((L0(k,alloc(s,t),t)+R0(k,alloc(s,t),t))*(mins[t]+1.0*alloc(s,t)/skips[t])+L1(k,alloc(s,t),t)-R1(k,alloc(s,t),t));
      }
    }
  }
  
  for(int j=0; j<pp; j++){
    for(int k=0; k<nc; k++){
      emult = exp(-1.0/skips[j]/h[k]);
      L0(k,0,j) = bin_y(k,0,j)/densities(k,0,j);
      L1(k,0,j) = -mins[j]*bin_y(k,0,j)/densities(k,0,j);
      R0(k,nbin-1,j) = 0.0;
      R1(k,nbin-1,j) = 0.0;
      for(int i=1; i<nbin; i++){
        L0(k,i,j) = bin_y(k,i,j)/densities(k,i,j) + emult*L0(k,i-1,j);
        L1(k,i,j) = -(mins[j]+(i+0.0)/skips[j])*bin_y(k,i,j)/densities(k,i,j) + emult*L1(k,i-1,j);
        R0(k,nbin-i-1,j) = emult*(bin_y(k,nbin-i,j)/densities(k,nbin-i,j)+R0(k,nbin-i,j));
        R1(k,nbin-i-1,j) = emult*((mins[j]+(nbin-i+0.0)/skips[j])*bin_y(k,nbin-i,j)/densities(k,nbin-i,j)+R1(k,nbin-i,j));
      }
    }
  }
  
  for(int s=0; s<n; s++){
    for(int t=0; t<pp; t++){
      //dp(s,t) -= .25/(n*mypi[y[s]])/h/h/h*((L0(y[s],alloc(s,t),t)+R0(y[s],alloc(s,t),t))*P(s,t)+L1(y[s],alloc(s,t),t)-R1(y[s],alloc(s,t),t));
      dp(s,t) -= .25/(n*mypi[y[s]])/h[y[s]]/h[y[s]]/h[y[s]]*((L0(y[s],alloc(s,t),t)+R0(y[s],alloc(s,t),t))*(mins[t]+1.0*alloc(s,t)/skips[t])+L1(y[s],alloc(s,t),t)-R1(y[s],alloc(s,t),t));
    }
  }
  
  for(int j=0; j<pp; j++){
    for(int i = 0; i<nbin; i++) for(int k=0; k<nc; k++) bin_y(k,i,j) = 0.0;
    for(int i=0; i<n; i++){
      
      
      
      //xe = (P(i,j) - mins[j]) * skips[j];
      //fl = floor(xe);
      for(int k=0; k<nc; k++) bin_y(k,alloc(i,j),j) += dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j)/mypi[k];
      //if(fl < (nbin - 1) && fl >= 0)
        //else if(fl >= (nbin - 1)) for(int k=0; k<nc; k++) bin_y(k,nbin-1,j) += dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j);
        //else for(int k=0; k<nc; k++) bin_y(k,0,j) += dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j);
    }
  }
  
  NumericMatrix Lnew(nbin,2);
  NumericMatrix Rnew(nbin,2);
  for(int t=0; t<pp; t++){
    for(int k=0; k<nc; k++){
      emult = exp(-1.0/skips[t]/h[k]);
      Lnew(0,0) = bin_y(k,0,t);
      Lnew(0,1) = -mins[t]*bin_y(k,0,t);
      Rnew(nbin-1,0) = 0.0;
      Rnew(nbin-1,1) = 0.0;
      for(int i=1; i<nbin; i++){
        Lnew(i,0) = bin_y(k,i,t) + emult*Lnew(i-1,0);
        Lnew(i,1) = -(mins[t]+(i+0.0)/skips[t])*bin_y(k,i,t) + emult*Lnew(i-1,1);
        Rnew(nbin-i-1,0) = emult*(bin_y(k,nbin-i,t)+Rnew(nbin-i,0));
        Rnew(nbin-i-1,1) = emult*((mins[t]+(nbin-i+0.0)/skips[t])*bin_y(k,nbin-i,t)+Rnew(nbin-i,1));
      }
      
      
      
      
      for(int s=0; s<n; s++){
        if(y[s]==k) dp(s,t) += mypi[k]*.25/(n+0.0)/h[k]/h[k]/h[k]*((Lnew(alloc(s,t),0)+Rnew(alloc(s,t),0))*(mins[t]+1.0*alloc(s,t)/skips[t])+Lnew(alloc(s,t),1)-Rnew(alloc(s,t),1));
      }
      // dencc[,k] is density in class k but excluding current variable
      //dp[y==k,dm] <- dp[y==k,dm] + wt[y==k]*fk_sum(p[,dm], wt*dencc[,k]/pr, h[k], x_eval = p[y==k,dm], type = 'dksum')/h[k]^2/sum(wt)
    }
  }
  
  arma::mat dV = X.t()*dp/(n+0.0);
  return(dV);
}


// [[Rcpp::export]]

double f_NB_exact(arma::mat V, arma::mat X, IntegerVector y, NumericVector mypi, NumericVector h){
  int n = arma::size(X)[0];
  int p = arma::size(X)[1];
  int pp = arma::size(V)[1];
  int nc = mypi.size();
  arma::vec nms(pp);
  for(int i=0; i<pp; i++) nms[i] = norm(V.col(i), 2);
  
  
  arma::mat P = X*V;
  
  IntegerVector sorts(n);
  
  IntegerMatrix orders(n,pp);
  for(int d=0; d<pp; d++){
    sorts = sort_index(P.col(d));
    for(int i = 0; i<n; i++) orders(i,d) = sorts[i];
  }
  
  
  double emult;
  
  arma::cube L0(nc, n, pp);
  arma::cube L1(nc, n, pp);
  arma::cube R0(nc, n, pp);
  arma::cube R1(nc, n, pp);
  for(int j=0; j<pp; j++){
    for(int k=0; k<nc; k++){
      if(y[orders(0,j)]==k){
        L0(k,0,j) = 1.0;
        L1(k,0,j) = -P(orders(0,j),j);
      }
      else{
        L0(k,0,j) = 0.0;
        L1(k,0,j) = -0.0;
      }
      R0(k,n-1,j) = 0.0;
      R1(k,n-1,j) = 0.0;
      for(int i=1; i<n; i++){
        emult = exp((P(orders(i-1,j),j)-P(orders(i,j),j))/h[k]);
        if(y[orders(i,j)]==k){
          L0(k,i,j) = 1.0 + emult*L0(k,i-1,j);
          L1(k,i,j) = -P(orders(i,j),j) + emult*L1(k,i-1,j);
        }
        else{
          L0(k,i,j) = emult*L0(k,i-1,j);
          L1(k,i,j) = emult*L1(k,i-1,j);
        }
        emult = exp((P(orders(n-i-1,j),j)-P(orders(n-i,j),j))/h[k]);
        if(y[orders(n-i,j)]==k){
          R0(k,n-i-1,j) = emult*(1.0+R0(k,n-i,j));
          R1(k,n-i-1,j) = emult*(P(orders(n-i,j),j)+R1(k,n-i,j));
        }
        else{
          R0(k,n-i-1,j) = emult*R0(k,n-i,j);
          R1(k,n-i-1,j) = emult*R1(k,n-i,j);
        }
      }
    }
  }
  
  
  
  
  
  arma::cube densities(nc,n,pp);
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<n; i++){
        densities(k,i,j) = 0.0;
      }
    }
  }
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<n; i++){
        densities(k,orders(i,j),j) += .25/(n*mypi[k])/h[k]*(L0(k,i,j)*(1.0+P(orders(i,j),j)/h[k])+L1(k,i,j)/h[k] + R0(k,i,j)*(1.0-P(orders(i,j),j)/h[k]) + R1(k,i,j)/h[k]);
      }
    }
  }
  
  
  
  double output = 0;
  
  double dentot;
  double denprod;
  
  for(int i=0; i<n; i++){
    dentot = 0.0;
    for(int k=0; k<nc; k++){
      denprod = 1.0*mypi[k];
      for(int j=0; j<pp; j++){
        denprod *= densities(k,i,j);
      }
      dentot += mypi[k]*denprod;
      //if(y[i]==k) dens(i,0) = mypi[k]*denprod;
      if(y[i]==k) output+= log(mypi[k]*denprod);
    }
    //dens(i,1) = dentot;
    output -= log(dentot);
    //output += (denc < 1e-100 ? log(denc) : -100) - (dentot < 1e-100 ? log(dentot) : -50);
  }
  output /= n+0.0;
  return(output);
  //return(dens);
}



// [[Rcpp::export]]

arma::mat df_NB_exact(arma::mat V, arma::mat X, IntegerVector y, NumericVector mypi, NumericVector h){
  int n = arma::size(X)[0];
  int p = arma::size(X)[1];
  int pp = arma::size(V)[1];
  int nc = mypi.size();
  arma::vec nms(pp);
  for(int i=0; i<pp; i++) nms[i] = norm(V.col(i), 2);
  
  
  arma::mat P = X*V;
  
  IntegerVector sorts(n);
  
  IntegerMatrix orders(n,pp);
  for(int d=0; d<pp; d++){
    sorts = sort_index(P.col(d));
    for(int i = 0; i<n; i++) orders(i,d) = sorts[i];
  }
  
  
  double emult;
  
  arma::cube L0(nc, n, pp);
  arma::cube L1(nc, n, pp);
  arma::cube R0(nc, n, pp);
  arma::cube R1(nc, n, pp);
  for(int j=0; j<pp; j++){
    for(int k=0; k<nc; k++){
      if(y[orders(0,j)]==k){
        L0(k,0,j) = 1.0;
        L1(k,0,j) = -P(orders(0,j),j);
      }
      else{
        L0(k,0,j) = 0.0;
        L1(k,0,j) = -0.0;
      }
      R0(k,n-1,j) = 0.0;
      R1(k,n-1,j) = 0.0;
      for(int i=1; i<n; i++){
        emult = exp((P(orders(i-1,j),j)-P(orders(i,j),j))/h[k]);
        if(y[orders(i,j)]==k){
          L0(k,i,j) = 1.0 + emult*L0(k,i-1,j);
          L1(k,i,j) = -P(orders(i,j),j) + emult*L1(k,i-1,j);
        }
        else{
          L0(k,i,j) = emult*L0(k,i-1,j);
          L1(k,i,j) = emult*L1(k,i-1,j);
        }
        emult = exp((P(orders(n-i-1,j),j)-P(orders(n-i,j),j))/h[k]);
        if(y[orders(n-i,j)]==k){
          R0(k,n-i-1,j) = emult*(1.0+R0(k,n-i,j));
          R1(k,n-i-1,j) = emult*(P(orders(n-i,j),j)+R1(k,n-i,j));
        }
        else{
          R0(k,n-i-1,j) = emult*R0(k,n-i,j);
          R1(k,n-i-1,j) = emult*R1(k,n-i,j);
        }
      }
    }
  }
  
  
  
  
  
  arma::cube densities(nc,n,pp);
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<n; i++){
        densities(k,i,j) = 0.0;
      }
    }
  }
  for(int k=0; k<nc; k++){
    for(int j=0; j<pp; j++){
      for(int i=0; i<n; i++){
        densities(k,orders(i,j),j) += .25/(n*mypi[k])/h[k]*(L0(k,i,j)*(1.0+P(orders(i,j),j)/h[k])+L1(k,i,j)/h[k] + R0(k,i,j)*(1.0-P(orders(i,j),j)/h[k]) + R1(k,i,j)/h[k]);
      }
    }
  }
  
  
  
  double dentot;
  double denprod;
  arma::mat dens(n,nc+1);
  double denc;
  
  //double eps = pow(.1, 100);
  
  for(int i=0; i<n; i++){
    dentot = 0.0;
    for(int k=0; k<nc; k++){
      denprod = 1.0;
      for(int j=0; j<pp; j++){
        denprod *= densities(k,i,j);
      }
      dentot += mypi[k]*denprod;
      dens(i,k) = denprod;
    }
    dens(i,nc) = dentot;
    //output += (denc < 1e-100 ? log(denc) : -100) - (dentot < 1e-100 ? log(dentot) : -50);
  }
  
  arma::mat dp(n,pp);
  
  int ix;
  
  for(int s=0; s<n; s++){
    for(int t=0; t<pp; t++){
      ix = orders(s,t);
      dp(ix,t) = -(.25/(n*mypi[y[ix]])/h[y[ix]]/h[y[ix]]/h[y[ix]]/densities(y[ix],ix,t)*((L0(y[ix],s,t)+R0(y[ix],s,t))*P(ix,t)+L1(y[ix],s,t)-R1(y[ix],s,t)));
      for(int k=0; k<nc; k++){
        dp(ix,t) += .25/(n+0.0)/h[k]/h[k]/h[k]/dens(ix,nc)*dens(ix,k)/densities(k,ix,t)*((L0(k,s,t)+R0(k,s,t))*P(ix,t)+L1(k,s,t)-R1(k,s,t));
      }
    }
  }
  
  //for(int j=0; j<pp; j++){
  //  for(int k=0; k<nc; k++){
  //    emult = exp(-1.0/skips[j]/h[k]);
  //    L0(k,0,j) = bin_y(k,0,j)/densities(k,0,j);
  //    L1(k,0,j) = -mins[j]*bin_y(k,0,j)/densities(k,0,j);
  //    R0(k,nbin-1,j) = 0.0;
  //    R1(k,nbin-1,j) = 0.0;
  //    for(int i=1; i<nbin; i++){
  //      L0(k,i,j) = bin_y(k,i,j)/densities(k,i,j) + emult*L0(k,i-1,j);
  //      L1(k,i,j) = -(mins[j]+(i+0.0)/skips[j])*bin_y(k,i,j)/densities(k,i,j) + emult*L1(k,i-1,j);
  //      R0(k,nbin-i-1,j) = emult*(bin_y(k,nbin-i,j)/densities(k,nbin-i,j)+R0(k,nbin-i,j));
  //      R1(k,nbin-i-1,j) = emult*((mins[j]+(nbin-i+0.0)/skips[j])*bin_y(k,nbin-i,j)/densities(k,nbin-i,j)+R1(k,nbin-i,j));
  //    }
  //  }
  //}
  
  
  
  for(int j=0; j<pp; j++){
    for(int k=0; k<nc; k++){
      if(y[orders(0,j)]==k){
        L0(k,0,j) = 1.0/densities(k,orders(0,j),j);
        L1(k,0,j) = -P(orders(0,j),j)/densities(k,orders(0,j),j);
      }
      else{
        L0(k,0,j) = 0.0;
        L1(k,0,j) = 0.0;
      }
      R0(k,n-1,j) = 0.0;
      R1(k,n-1,j) = 0.0;
      for(int i=1; i<n; i++){
        emult = exp((P(orders(i-1,j),j)-P(orders(i,j),j))/h[k]);
        if(y[orders(i,j)]==k){
          L0(k,i,j) = 1.0/densities(k,orders(i,j),j) + emult*L0(k,i-1,j);
          L1(k,i,j) = -P(orders(i,j),j)/densities(k,orders(i,j),j) + emult*L1(k,i-1,j);
        }
        else{
          L0(k,i,j) = emult*L0(k,i-1,j);
          L1(k,i,j) = emult*L1(k,i-1,j);
        }
        emult = exp((P(orders(n-i-1,j),j)-P(orders(n-i,j),j))/h[k]);
        if(y[orders(n-i,j)]==k){
          R0(k,n-i-1,j) = emult*(1.0/densities(k,orders(n-i,j),j)+R0(k,n-i,j));
          R1(k,n-i-1,j) = emult*(P(orders(n-i,j),j)/densities(k,orders(n-i,j),j)+R1(k,n-i,j));
        }
        else{
          R0(k,n-i-1,j) = emult*R0(k,n-i,j);
          R1(k,n-i-1,j) = emult*R1(k,n-i,j);
        }
      }
    }
  }
  
  
  
  for(int s=0; s<n; s++){
    for(int t=0; t<pp; t++){
      ix = orders(s,t);
      dp(ix,t) -= .25/(n*mypi[y[ix]])/h[y[ix]]/h[y[ix]]/h[y[ix]]*((L0(y[ix],s,t)+R0(y[ix],s,t))*P(ix,t)+L1(y[ix],s,t)-R1(y[ix],s,t));
    }
  }
  
  /*for(int j=0; j<pp; j++){
   for(int i = 0; i<nbin; i++) for(int k=0; k<nc; k++) bin_y(k,i,j) = 0.0;
   for(int i=0; i<n; i++){
   
   
   
   //xe = (P(i,j) - mins[j]) * skips[j];
   //fl = floor(xe);
   for(int k=0; k<nc; k++) bin_y(k,alloc(i,j),j) += dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j)/mypi[k];
   //if(fl < (nbin - 1) && fl >= 0)
   //else if(fl >= (nbin - 1)) for(int k=0; k<nc; k++) bin_y(k,nbin-1,j) += dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j);
   //else for(int k=0; k<nc; k++) bin_y(k,0,j) += dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j);
   }
  }*/
  
  // dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j)/mypi[k]
  NumericMatrix Lnew(n,2);
  NumericMatrix Rnew(n,2);
  for(int t=0; t<pp; t++){
    for(int k=0; k<nc; k++){
      //if(y[orders(0,t)]==k){
      // dens(i,k)/dens(i,nc)/densities(k,alloc(i,j),j)/mypi[k]
      Lnew(0,0) = dens(orders(0,t),k)/dens(orders(0,t),nc)/densities(k,orders(0,t),t)/mypi[k];
      Lnew(0,1) = -P(orders(0,t),t)*dens(orders(0,t),k)/dens(orders(0,t),nc)/densities(k,orders(0,t),t)/mypi[k];
      //}
      //else{
      //  Lnew(0,0) = 0.0;
      //  Lnew(0,1) = 0.0;
      //}
      Rnew(n-1,0) = 0.0;
      Rnew(n-1,1) = 0.0;
      for(int i=1; i<n; i++){
        emult = exp((P(orders(i-1,t),t)-P(orders(i,t),t))/h[k]);
        //if(y[orders(i,t)]==k){
        Lnew(i,0) = dens(orders(i,t),k)/dens(orders(i,t),nc)/densities(k,orders(i,t),t)/mypi[k] + emult*Lnew(i-1,0);
        Lnew(i,1) = -P(orders(i,t),t)*dens(orders(i,t),k)/dens(orders(i,t),nc)/densities(k,orders(i,t),t)/mypi[k] + emult*Lnew(i-1,1);
        //}
        //else{
        //  Lnew(i,0) = emult*Lnew(i-1,0);
        //  Lnew(i,1) = emult*Lnew(i-1,1);
        //}
        emult = exp((P(orders(n-i-1,t),t)-P(orders(n-i,t),t))/h[k]);
        //if(y[orders(n-i,t)]==k){
        Rnew(n-i-1,0) = emult*(dens(orders(n-i,t),k)/dens(orders(n-i,t),nc)/densities(k,orders(n-i,t),t)/mypi[k]+Rnew(n-i,0));
        Rnew(n-i-1,1) = emult*(P(orders(n-i,t),t)*dens(orders(n-i,t),k)/dens(orders(n-i,t),nc)/densities(k,orders(n-i,t),t)/mypi[k]+Rnew(n-i,1));
        //}
        //else{
        //  Rnew(n-i-1,0) = emult*Rnew(n-i,0);
        //  Rnew(n-i-1,1) = emult*Rnew(n-i,1);
        //}
      }
      for(int s=0; s<n; s++){
        ix = orders(s,t);
        if(y[ix]==k) dp(ix,t) += mypi[k]*.25/(n+0.0)/h[k]/h[k]/h[k]*((Lnew(s,0)+Rnew(s,0))*P(ix,t)+Lnew(s,1)-Rnew(s,1));
      }
    }
  }
  
  arma::mat dV = X.t()*dp/(n+0.0);
  return(dV);
}


